public class FalscheDeklerationException extends Exception {
    public FalscheDeklerationException(String message) {
        super(message);
    }
}