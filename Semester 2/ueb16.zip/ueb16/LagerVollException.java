public class LagerVollException extends Exception {
    public LagerVollException() {
        super("Lager voll");
    }
}
