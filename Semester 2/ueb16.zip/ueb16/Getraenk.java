
/**
 * Abstrakte Klasse Getraenk.
 * 
 * @Jonas_Neu_&_Marc_Perwak
 */
public abstract class Getraenk {
}
